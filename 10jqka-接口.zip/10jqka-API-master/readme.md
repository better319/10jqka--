# 同花顺API交易协议 QQ群63234102
代码完善中，可转债打新已完成。
## 使用方法
1. 修改constants.py中的设备信息参数:
TYPE = ''
UDID = ''
IMEI = ''
IMSI = ''
MAC = ''
2. 修改hexin.py的账户信息
//券商账户
wtaccount = ''
//券商密码
wtpassword = ''
//券商参数, 可以从券商参数.txt获取
qsid = ''
wtid = ''
dtkltype = ''
3. 运行hexin.py
## 分析笔记
[挂机赚钱之可转债打新-同花顺逆向分析笔记](https://github.com/limitget/10jqka-API/blob/master/document/%E6%8C%82%E6%9C%BA%E8%B5%9A%E9%92%B1%E4%B9%8B%E5%8F%AF%E8%BD%AC%E5%80%BA%E6%89%93%E6%96%B0-%E5%90%8C%E8%8A%B1%E9%A1%BA%E9%80%86%E5%90%91%E5%88%86%E6%9E%90%E7%AC%94%E8%AE%B0.md)


