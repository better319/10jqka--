class StuffTableStruct:
    u = False
    tableHead = []
    n = []
    caption = ""
    r = {}
    q = {}
    s = 0
    t = 0
    o = 0
    p = 0

    def __init__(self, boolean):
        self.u = boolean
